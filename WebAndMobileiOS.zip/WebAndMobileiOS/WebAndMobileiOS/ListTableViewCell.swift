//
//  ListTableViewCell.swift
//  WebAndMobileiOS
//
//  Created by Jordan Lu on 2/18/16.
//  Copyright © 2016 Jordan Lu. All rights reserved.
//

import UIKit

class ListTableViewCell: UITableViewCell {
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var dueLabel: UILabel!
    
}