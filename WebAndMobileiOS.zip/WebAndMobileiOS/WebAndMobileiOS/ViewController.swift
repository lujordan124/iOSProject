//
//  ViewController.swift
//  WebAndMobileiOS
//
//  Created by Jordan Lu on 2/18/16.
//  Copyright © 2016 Jordan Lu. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, InfoViewControllerDelegate {

    @IBOutlet weak var tableView: UITableView!
    
    var list : [(title: String, description: String, dueDate: NSDate, due: String)] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return list.count
    }

    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell: ListTableViewCell = tableView.dequeueReusableCellWithIdentifier("reuseIdentifier", forIndexPath: indexPath) as! ListTableViewCell
        
        cell.titleLabel.text = list[indexPath.row].title
        cell.dueLabel.text = list[indexPath.row].due
        
        return cell
    }
    
    func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        return true
    }
    
    func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        if (editingStyle == UITableViewCellEditingStyle.Delete) {
            list.removeAtIndex(indexPath.row)
            tableView.reloadData()
        }
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        let secondViewController = self.storyboard?.instantiateViewControllerWithIdentifier("infoViewController")
        
        self.navigationController?.pushViewController(secondViewController!, animated: true)
    }
    
    func updateList(title: String, description: String, due: NSDate) {
        let dateFormatter = NSDateFormatter()
        dateFormatter.dateStyle = NSDateFormatterStyle.ShortStyle
        dateFormatter.timeStyle = NSDateFormatterStyle.ShortStyle
        let dueDate = dateFormatter.stringFromDate(due)
        
        let value = (title, description, due, dueDate)
        list.append(value)
        
        list.sortInPlace { (lhs, rhs) -> Bool in
            return lhs.due.compare(rhs.due) == .OrderedAscending
        }
        
        tableView.reloadData()
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        let infoVC = segue.destinationViewController as! InfoViewController
        infoVC.delegate = self
        
    }
}

