//
//  InfoViewController.swift
//  WebAndMobileiOS
//
//  Created by Jordan Lu on 2/18/16.
//  Copyright © 2016 Jordan Lu. All rights reserved.
//

import UIKit

protocol InfoViewControllerDelegate {
    func updateList(title: String, description: String, due: NSDate)
}

class InfoViewController: UIViewController {
    
    @IBOutlet weak var textField: UITextField!
    @IBOutlet weak var textView: UITextView!
    @IBOutlet weak var datePicker: UIDatePicker!
    @IBOutlet weak var scrollView: UIScrollView!
    
    @IBOutlet weak var bottomConstraint: NSLayoutConstraint!
    
    var delegate: InfoViewControllerDelegate?

    var titlePrev: String!
    var descriptionPrev: String!
    var dueDate: NSDate!
    
    @IBAction func submitButtonPressed(sender: AnyObject) {
        delegate?.updateList(self.textField.text!, description: self.textView.text!, due: self.datePicker.date)
        self.navigationController?.popViewControllerAnimated(true)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if (titlePrev != nil && descriptionPrev != nil && dueDate != nil) {
            self.textField.text = titlePrev
            self.textView.text = descriptionPrev
            self.datePicker.date = dueDate
        }
        
        NSNotificationCenter.defaultCenter().addObserver(self, selector: Selector("keyboardWillShow:"), name:UIKeyboardWillShowNotification, object: nil);
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func keyboardWillShow(notification: NSNotification) {
        var info = notification.userInfo!
        let keyboardFrame: CGRect = (info[UIKeyboardFrameEndUserInfoKey] as! NSValue).CGRectValue()
        
        var contentInset:UIEdgeInsets = self.scrollView.contentInset
        contentInset.bottom = keyboardFrame.size.height
        self.scrollView.contentInset = contentInset
    }
    
}